﻿using Microsoft.AspNetCore.Identity;

namespace WorldCitiesAPI.Data.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
